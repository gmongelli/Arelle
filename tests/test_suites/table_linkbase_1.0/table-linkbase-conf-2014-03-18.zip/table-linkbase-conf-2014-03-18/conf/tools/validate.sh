#!/bin/bash
BASEDIR=`dirname "$0"`
MAINJAR="$BASEDIR/tableLinkbaseConformanceSuiteValidator.jar"

if [ -z "$JAVA_HOME" ] ; then
  JAVA=java
else
  JAVA="$JAVA_HOME/bin/java"
fi

echo "Running: " "$JAVA" -Done-jar.silent=true -jar "$MAINJAR" -m org.xbrl.conformance.suite.validator.table.XmlInfosetValidatorModule "$@"
exec             "$JAVA" -Done-jar.silent=true -jar "$MAINJAR" -m org.xbrl.conformance.suite.validator.table.XmlInfosetValidatorModule "$@"
